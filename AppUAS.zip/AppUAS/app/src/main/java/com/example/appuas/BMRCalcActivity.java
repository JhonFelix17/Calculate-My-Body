package com.example.appuas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class BMRCalcActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bmr);
        getSupportActionBar().setTitle("Calculate My Body");

    }
}