package com.example.appuas;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class TDEECalcActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tdee);
        getSupportActionBar().setTitle("Calculate My Body");

    }
}